﻿namespace XFramework.Web.Model_Test
{
    public class PersonCallOut
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}